let a = b => 10 + b;
module.exports.func = a;
// console.log(module);